class HomesController < ApplicationController
  def index
  end

  def create
    homes = Homes.new(homes_params)
    list.save

    redirect_to books_path(list.id)

  end

  def show
    @homes = Home.top(params[:id])
  end

  def new
  end

  def edit
  end
end
