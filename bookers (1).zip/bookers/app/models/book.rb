class Book < ApplicationRecord
end
